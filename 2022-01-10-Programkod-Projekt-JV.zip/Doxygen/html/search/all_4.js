var searchData=
[
  ['isalive_0',['isAlive',['../class_player.html#a06e38c0f57e67eb006c9d09779bd8f8f',1,'Player']]]
];

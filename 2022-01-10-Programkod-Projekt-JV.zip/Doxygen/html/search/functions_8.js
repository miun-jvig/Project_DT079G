var searchData=
[
  ['player_0',['Player',['../class_player.html#a4f4eaf8b3b531796dda449605672e9ae',1,'Player']]]
];
